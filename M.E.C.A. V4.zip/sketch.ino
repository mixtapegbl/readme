/*================================================================================
           MANUAL DE OPERAÇÃO - ECOSSISTEMA INTELIGENTE MIXTAPE v4.0
================================================================================

1. ESPECIFICAÇÕES DO AMBIENTE ALVO
--------------------------------------------------------------------------------
Este sistema foi projetado para a monitoração climática contínua de:
* Salas de Servidores, Roteadores e Infraestrutura de TI (Data Centers)
* Ambientes de Desenvolvimento de Sistemas Embarcados

Os limites operacionais configurados protegem os componentes contra:
* Superaquecimento de microcontroladores e chips lógicos (T > 30.0°C)
* Choques térmicos ou estresse de solda fria (T < 20.0°C)
* Oxidação e corrosão de trilhas na protoboard por alta umidade (H > 60.0%)
* Descargas eletrostáticas por ar excessivamente seco (H < 30.0%)

2. REQUISITOS E COMPONENTES UTILIZADOS (HARDWARE)
--------------------------------------------------------------------------------
* 1x Microcontrolador Arduino Uno R3 (Plataforma de Processamento)
* 1x Display LCD 16x2 com Módulo de Comunicação I2C (Endereço 0x27)
* 1x Sensor de Temperatura e Umidade de Alta Precisão DHT22 (Pino Digital 2)
* 1x Módulo Relógio em Tempo Real (RTC) DS1307 I2C (Sincronização de Data/Hora)
* 5x Botões Pulsadores (Up, Down, Menu, Select, Mode) com resistores Pull-Up internos

3. LÓGICA DE AUDITORIA E REGISTRO DE DADOS (EEPROM)
--------------------------------------------------------------------------------
O sistema realiza a leitura dos sensores em tempo real. A gravação na memória 
EEPROM interna ocorre estritamente sob as seguintes regras:
* Frequência de Verificação: Ocorre de minuto em minuto (Bloqueio por software).
* Condição de Gravação: Os dados SÓ são persistidos na memória se QUALQUER uma das 
  variáveis (Temperatura ou Umidade) ultrapassar os limites de segurança (Triggers).
* Formato do Log: Salva o Timestamp Unix (4 bytes), Temperatura x100 (2 bytes)
  e Umidade x100 (2 bytes), ocupando 8 bytes por registro em um buffer circular 
  de até 100 posições.

4. DADOS DA EQUIPE E IDENTIFICAÇÃO CORPORATIVA
--------------------------------------------------------------------------------
* Nome do Grupo: Mixtape
* Líder e Desenvolvedor: Gabriel Souza
* Laboratórios de Desenvolvimento e Eletrônica (SENAI / FIAP)
* Área de Atuação: Análise e Desenvolvimento de Sistemas (ADS)
* Repositório GitHub: https://github.com/mixtapegbl
* Canal do YouTube: https://www.youtube.com/@mixtape-s39
================================================================================*/

// ============================================================================
//               PROJETO MIXTAPE v4.0 - SISTEMA MULTIVERSATIL
// ============================================================================

#include <LiquidCrystal_I2C.h>  // Controla o display LCD via barramento de 2 fios I2C
#include <RTClib.h>              // Gerencia a comunicação com o chip de tempo DS1307
#include <Wire.h>                // Biblioteca nativa para protocolo I2C (SDA/SCL)
#include <EEPROM.h>              // Permite ler e gravar dados mesmo após desligar o Arduino
#include "DHT.h"                 // Driver oficial para leitura digital dos sensores DHT

#define LOG_OPTION 1     // Habilita (1) ou desabilita (0) o despejo de logs na Serial
#define SERIAL_OPTION 1  // Ativa o Monitor Serial para rastreamento de telemetria
#define UTC_OFFSET -3    // Ajuste de fuso horário local para o Horário de Brasília

// --- MAPEAMENTO FÍSICO DO SENSOR DHT22 ---
#define DHTPIN 2         // Pino digital conectado ao terminal de dados do sensor
#define DHTTYPE DHT22    // Define o modelo exato como DHT22 (Sensor de precisão)
DHT dht(DHTPIN, DHTTYPE);// Inicializa a instância do sensor DHT

LiquidCrystal_I2C lcd(0x27, 16, 2); // Instancia o LCD no endereço estável I2C 0x27
RTC_DS1307 RTC;                    // Instancia o relógio de tempo real

// --- PINAGEM DO TECLADO DE CONTROLE (5 BOTÕES) ---
#define BTN_UP     3     // Botão de navegação para cima / incremento de valores
#define BTN_DOWN   4     // Botão de navegação para baixo / decremento de valores
#define BTN_MENU   5     // Botão para alternar entre as abas principais de exibição
#define BTN_SELECT 6     // Botão para entrar/sair do Histórico e avançar campos
#define BTN_MODE   7     // Botão para acionar o modo de ajuste de hora (clique longo)

// --- PARAMETRIZAÇÃO DA MEMÓRIA DE MASSA (EEPROM) ---
const int maxRecords = 100;    // Limite máximo de registros para não estourar a EEPROM
const int recordSize = 8;      // Cada log ocupa exatamente 8 bytes na memória do Uno
int startAddress = 0;          // Endereço inicial da tabela de logs
int endAddress = maxRecords * recordSize; // Endereço limite de escrita (800 bytes)
int currentAddress = 0;        // Ponteiro dinâmico do endereço de gravação atual
int lastLoggedMinute = -1;     // Armazena o último minuto para evitar gravações duplicadas

// --- LIMITES TÉCNICOS PARA MONITORAMENTO DE LABS DE TI / ELETRÔNICA ---
float trigger_t_min = 20.0;    // Temperatura mínima aceitável (Evita frio extremo/condensação)
float trigger_t_max = 30.0;    // Temperatura máxima limite (Evita queima por superaquecimento)
float trigger_u_min = 30.0;    // Umidade mínima aceitável (Evita estática no ar)
float trigger_u_max = 60.0;    // Umidade máxima limite (Evita oxidação nas placas)

float ultimaTemperatura = 0.0; // Registra a medição anterior para cálculo de tendência estatística

// --- ESTRUTURA DOS MENUS (MÁQUINA DE ESTADOS FINITOS) ---
enum ModoMenu { NORMAL, HISTORICO, AJUSTAR };
ModoMenu modoAtual = NORMAL;   // O sistema inicia sempre na tela principal de varredura

int horaSelecionada = 0;       // Armazena a hora que o usuário deseja consultar no histórico
int campoEditando = 0;         // Controla qual campo do relógio está sendo modificado (0=Dia, 4=Min)
bool alternarTela = false;     // Chave lógica para alternar visualização entre Sensores e Relógio

// Variáveis voláteis usadas temporariamente durante o ajuste do calendário
int adjDia, adjMes, adjAno, adjHora, adjMin;

// --- MATRIZES DE BYTES DA ANIMAÇÃO K7 MIXTAPE (CUSTOM CHARS NA CGRAM DO LCD) ---
byte k7_rolo_f1[8] = { B11111, B10001, B10101, B11111, B10101, B10001, B11111, B00000 }; // Frame 1 fita
byte k7_rolo_f2[8] = { B11111, B10101, B10001, B11111, B10001, B10101, B11111, B00000 }; // Frame 2 fita
byte onda_baixa[8]  = { B00000, B00000, B00000, B00000, B00000, B00000, B11111, B11111 }; // Sinal wireless fraco
byte onda_media[8]  = { B00000, B00000, B00000, B11111, B11111, B00000, B11111, B11111 }; // Sinal wireless médio
byte onda_maxima[8] = { B11111, B11111, B00000, B11111, B11111, B00000, B11111, B11111 }; // Sinal wireless máximo

// --- ÍCONES DE TENDÊNCIA TÉRMICA (MÉDIA MÓVEL PREDITIVA) ---
byte seta_subindo[8]  = { B00100, B01110, B10101, B00100, B00100, B00100, B00100, B00000 }; // Temperatura subindo
byte seta_estavel[8]  = { B00000, B00100, B00110, B11111, B11111, B00110, B00100, B00000 }; // Temperatura estabilizada
byte seta_descendo[8] = { B00100, B00100, B00100, B00100, B10101, B01110, B00100, B00000 }; // Temperatura caindo

// --- ALGORITMO CINEMATOGRÁFICO DE INTRODUÇÃO (GRAVADO NA MEMÓRIA FLASH) ---
void executarAnimacaoMixtape() {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(" LOADING SYSTEM "); // Mensagem de boot inicial
    
    // Aloca os caracteres da fita e da barra gráfica na tabela CGRAM do LCD
    lcd.createChar(0, k7_rolo_f1);
    lcd.createChar(1, onda_baixa);
    
    // Desenha o chassi estrutural da fita K7 clássica no visor
    lcd.setCursor(1, 1); lcd.print("[");
    lcd.setCursor(2, 1); lcd.write(byte(0)); // Carrega rolo esquerdo
    lcd.setCursor(3, 1); lcd.print("===[");
    lcd.setCursor(7, 1); lcd.print("4.0");    // Identificador de versão do firmware
    lcd.setCursor(10, 1); lcd.print("]==");
    lcd.setCursor(14, 1); lcd.write(byte(0)); // Carrega rolo direito
    lcd.setCursor(15, 1); lcd.print("]");
    delay(400);

    // Ciclo de rotação mecânica (Simula a fita girando de verdade no visor)
    for (int giro = 0; giro < 4; giro++) {
        lcd.createChar(0, k7_rolo_f2); delay(150); // Alterna para frame 2
        lcd.createChar(0, k7_rolo_f1); delay(150); // Retorna para frame 1
    }

    // Efeito gráfico de pulso de conexão IoT
    lcd.createChar(1, onda_media); delay(200);
    lcd.createChar(1, onda_maxima); delay(300);

    // Efeito de transição estilo cortina de estrelas
    lcd.clear();
    for(int col = 0; col < 16; col++) {
        lcd.setCursor(col, 0); lcd.print("*");
        lcd.setCursor(15 - col, 1); lcd.print("*");
        delay(30); // Controla a velocidade do varrimento físico
    }
    delay(100);
    lcd.clear();

    // Fixa a marca de liderança do Gabriel Souza na tela inicial
    lcd.setCursor(4, 0); lcd.print("MIXTAPE");
    lcd.setCursor(0, 1); lcd.print("ADS & ENGENHARIA");
    delay(1800); // Tempo de exposição da marca institucional
    lcd.clear();
    
    // Sobrescreve a CGRAM liberando memória para os ponteiros de tendência preditiva
    lcd.createChar(5, seta_subindo);
    lcd.createChar(6, seta_estavel);
    lcd.createChar(7, seta_descendo);
}

// --- CONFIGURAÇÃO DE INICIALIZAÇÃO DO ARDUINO ---
void setup() {
    // Configura os pinos digitais dos botões como entradas com resistores ativos para evitar ruído flutuante
    pinMode(BTN_UP, INPUT_PULLUP);
    pinMode(BTN_DOWN, INPUT_PULLUP);
    pinMode(BTN_MENU, INPUT_PULLUP);
    pinMode(BTN_SELECT, INPUT_PULLUP);
    pinMode(BTN_MODE, INPUT_PULLUP);
    pinMode(LED_BUILTIN, OUTPUT); // Configura o LED da placa para alertas visuais rápidos

    if (SERIAL_OPTION) {
        Serial.begin(9600); // Abre o canal de comunicação serial a 9600 bps
        Serial.println(F("[FIRMWARE] Ecossistema Instalado. Inicializando Setup..."));
    }

    Wire.begin();  // Inicializa o mestre do barramento I2C
    dht.begin();   // Liga o aquecedor interno do DHT22 e inicia leituras
    lcd.init();    // Envia comandos de inicialização para o driver HD44780 do LCD
    lcd.backlight(); // Acende os LEDs de iluminação traseira do LCD

    executarAnimacaoMixtape(); // Invoca a assinatura visual do projeto

    if (RTC.begin()) {
        // Sincroniza de forma automática a hora do hardware com o momento exato do upload
        RTC.adjust(DateTime(F(__DATE__), F(__TIME__)));
    }
    EEPROM.begin(); // Habilita o subsistema de memória não-volátil

    // Coleta a primeira amostra estática para servir de base para o indicador de tendência
    ultimaTemperatura = dht.readTemperature();
    if (isnan(ultimaTemperatura)) ultimaTemperatura = 24.0;
}

void loop() {
    // --- 1. SESSÃO DE TEMPO E COMPENSAÇÃO DE FUSO HORÁRIO ---
    DateTime now = RTC.now(); // Puxa os dados atuais direto dos registradores do DS1307
    uint32_t localUnix = now.unixtime() + (UTC_OFFSET * 3600); // Aplica fuso em segundos (UTC-3)
    DateTime adjustedTime = DateTime(localUnix); // Reconstrói o calendário corrigido

    // --- 2. COLETA E VALIDAÇÃO DE TELEMETRIA ---
    float humidity = dht.readHumidity();      // Solicita leitura digital da umidade relativo do ar
    float temperature = dht.readTemperature(); // Solicita leitura digital da temperatura ambiente

    // Aborta o ciclo se o sensor desconectar ou falhar, evitando congelar a tela com lixo
    if (isnan(humidity) || isnan(temperature)) {
        lcd.setCursor(0, 0); lcd.print("ERR: FALHA DHT22");
        delay(1000);
        return;
    }

    // --- 3. ALGORITMO DE AUDITORIA DE SEGURANÇA (EEPROM MINUTADA) ---
    if (adjustedTime.minute() != lastLoggedMinute) {
        lastLoggedMinute = adjustedTime.minute(); // Atualiza trava para rodar apenas uma vez por minuto
        ultimaTemperatura = temperature;          // Atualiza histórico para cálculo de tendência térmica

        // Se houver qualquer violação climática nos limites do Lab/Servidores, grava em disco
        if (temperature < trigger_t_min || temperature > trigger_t_max || humidity < trigger_u_min || humidity > trigger_u_max) {
            int tempInt = (int)(temperature * 100); // Converte float para int (economiza espaço de RAM/EEPROM)
            int humiInt = (int)(humidity * 100);    // Converte float para int
            
            EEPROM.put(currentAddress, localUnix);      // Salva data/hora (Bytes 0-3)
            EEPROM.put(currentAddress + 4, tempInt);    // Salva temperatura (Bytes 4-5)
            EEPROM.put(currentAddress + 6, humiInt);    // Salva umidade (Bytes 6-7)
            
            currentAddress += recordSize;               // Avança para o próximo bloco livre de 8 bytes
            if (currentAddress >= endAddress) currentAddress = 0; // Se encher, reinicia do começo (Circular)
        }
    }

    // --- 4. VARREDURA LÓGICA DO TECLADO (ANTI-DEBOUNCING) ---
    bool pressionouUp    = (digitalRead(BTN_UP) == LOW);
    bool pressionouDown  = (digitalRead(BTN_DOWN) == LOW);
    bool pressionouMenu  = (digitalRead(BTN_MENU) == LOW);
    bool pressionouSel   = (digitalRead(BTN_SELECT) == LOW);
    bool pressionouMode  = (digitalRead(BTN_MODE) == LOW);

    // Ativação do modo calibração por clique prolongado (2 segundos no botão MODE)
    if (pressionouMode) {
        delay(200);
        unsigned long tempoClique = millis();
        while (digitalRead(BTN_MODE) == LOW) {
            if (millis() - tempoClique > 2000) {
                if (modoAtual != AJUSTAR) {
                    modoAtual = AJUSTAR; campoEditando = 0;
                    adjDia = adjustedTime.day(); adjMes = adjustedTime.month(); adjAno = adjustedTime.year();
                    adjHora = adjustedTime.hour(); adjMin = adjustedTime.minute();
                    lcd.blink(); // Ativa cursor piscante de edição
                }
                break;
            }
        }
    }

    // Gerenciador de transição de menus (SELECT entra e sai da auditoria)
    if (pressionouSel) {
        delay(250); // Delay anti-repetição táctil
        if (modoAtual == NORMAL) modoAtual = HISTORICO;
        else if (modoAtual == HISTORICO) modoAtual = NORMAL;
        else if (modoAtual == AJUSTAR) {
            campoEditando++; // Avança entre os campos (Dia -> Mês -> Ano -> Hora -> Minuto)
            if (campoEditando > 4) { modoAtual = NORMAL; lcd.noBlink(); } // Finaliza calibração
        }
    }

    if (pressionouMenu && modoAtual == NORMAL) {
        delay(250);
        alternarTela = !alternarTela; // Alterna exibição das abas da tela estável
        lcd.clear();
    }

    // --- 5. MÁQUINA DE ESTADOS DO DISPLAY LCD (IMPRESSÃO SEM STREAMS DE FLOATS) ---
    if (modoAtual == NORMAL) {
        // Estado de Emergência / Crítico: Limites violados
        if (temperature < trigger_t_min || temperature > trigger_t_max || humidity < trigger_u_min || humidity > trigger_u_max) {
            lcd.setCursor(0, 0); lcd.print("!!/-/ALERTA/-/!! ");
            lcd.setCursor(0, 1); lcd.print("T:"); lcd.print(temperature, 1);
            lcd.print("C H:"); lcd.print(humidity, 1); lcd.print("%  ");
        } else {
            // Estado Saudável e Controlado
            if (!alternarTela) {
                // Linha 0: Mostra Temperatura Alinhada e Hora na extrema direita
                lcd.setCursor(0, 0); lcd.print("T: "); lcd.print(temperature, 1); lcd.print(" C   ");
                lcd.setCursor(11, 0);
                if (adjustedTime.hour() < 10) lcd.print("0"); lcd.print(adjustedTime.hour()); lcd.print(":");
                if (adjustedTime.minute() < 10) lcd.print("0"); lcd.print(adjustedTime.minute());

                // Linha 1: Mostra Umidade Alinhada e a sua Abreviação Homologada (MXTAPE) à direita
                lcd.setCursor(0, 1); lcd.print("H: "); lcd.print(humidity, 1); lcd.print(" % MXTAPE");
                
                // Processa e plota o caractere customizado de tendência térmica preditiva
                lcd.setCursor(9, 0);
                if (temperature > ultimaTemperatura + 0.05) lcd.write(5);      // Tendência de Alta
                else if (temperature < ultimaTemperatura - 0.05) lcd.write(7); // Tendência de Queda
                else lcd.write(6);                                             // Clima Estabilizado
            } else {
                // Aba 2: Calendário e Relógio de Precisão Estilo Código do Professor
                lcd.setCursor(0, 0); lcd.print("DATA: "); 
                if (adjustedTime.day() < 10) lcd.print("0"); lcd.print(adjustedTime.day()); lcd.print("/");
                if (adjustedTime.month() < 10) lcd.print("0"); lcd.print(adjustedTime.month()); lcd.print("/");
                lcd.print(adjustedTime.year());

                lcd.setCursor(0, 1); lcd.print("HORA: ");
                if (adjustedTime.hour() < 10) lcd.print("0"); lcd.print(adjustedTime.hour()); lcd.print(":");
                if (adjustedTime.minute() < 10) lcd.print("0"); lcd.print(adjustedTime.minute()); lcd.print(":");
                if (adjustedTime.second() < 10) lcd.print("0"); lcd.print(adjustedTime.second());
            }
        }
    } 
    else if (modoAtual == HISTORICO) {
        // Filtro por hora usando as teclas UP/DOWN
        if (pressionouUp)   { delay(200); horaSelecionada = (horaSelecionada + 1) % 24; lcd.clear(); }
        if (pressionouDown) { delay(200); horaSelecionada = (horaSelecionada - 1 + 24) % 24; lcd.clear(); }

        float tHist = 0.0, hHist = 0.0; bool registroAchado = false;
        // Varre os setores físicos da EEPROM buscando logs gravados na hora selecionada
        for (int adr = startAddress; adr < endAddress; adr += recordSize) {
            uint32_t tstamp; int tempInt, humiInt; 
            EEPROM.get(adr, tstamp);
            if (tstamp != 0xFFFFFFFF && tstamp > 0) {
                DateTime dtHist = DateTime(tstamp);
                int hHistReal = dtHist.hour() + UTC_OFFSET;
                if (hHistReal < 0) hHistReal += 24;
                if (hHistReal == horaSelecionada) {
                    EEPROM.get(adr + 4, tempInt); EEPROM.get(adr + 6, humiInt);
                    tHist = tempInt / 100.0; hHist = humiInt / 100.0; 
                    registroAchado = true; break;
                }
            }
        }
        lcd.setCursor(0, 0); lcd.print("HISTORICO: "); lcd.print(horaSelecionada); lcd.print("h  ");
        lcd.setCursor(0, 1);
        if (registroAchado) {
            lcd.print("T:"); lcd.print(tHist, 1); lcd.print("C H:"); lcd.print(hHist, 1); lcd.print("%   ");
        } else {
            lcd.print("* SEM REGISTRO *"); // Indica ambiente seguro na hora pesquisada
        }
    } 
    else if (modoAtual == AJUSTAR) {
        int variacao = 0;
        if (pressionouUp)   { delay(200); variacao = 1; }
        if (pressionouDown) { delay(200); variacao = -1; }

        if (variacao != 0) {
            if (campoEditando == 0) adjDia  = constrain(adjDia + variacao, 1, 31);
            if (campoEditando == 1) adjMes  = constrain(adjMes + variacao, 1, 12);
            if (campoEditando == 2) adjAno  = constrain(adjAno + variacao, 2026, 2040);
            if (campoEditando == 3) adjHora = (adjHora + variacao + 24) % 24;
            if (campoEditando == 4) adjMin  = (adjMin + variacao + 60) % 60;
            
            int horaEnvio = adjHora - UTC_OFFSET;
            int diaEnvio = adjDia;
            if (horaEnvio >= 24) { horaEnvio -= 24; diaEnvio++; }
            RTC.adjust(DateTime(adjAno, adjMes, diaEnvio, horaEnvio, adjMin, 0)); // Salva nova configuração no chip RTC
        }

        lcd.setCursor(0, 0); lcd.print("dd/mm/aaaa  hora");
        lcd.setCursor(0, 1);
        if(adjDia<10) lcd.print("0"); lcd.print(adjDia); lcd.print("/");
        if(adjMes<10) lcd.print("0"); lcd.print(adjMes); lcd.print("/");
        lcd.print(adjAno); lcd.print("  ");
        if(adjHora<10) lcd.print("0"); lcd.print(adjHora); lcd.print(":");
        if(adjMin<10) lcd.print("0"); lcd.print(adjMin);

        // Reposiciona o cursor piscante no local exato do campo selecionado
        if (campoEditando == 0) lcd.setCursor(1, 1);
        else if (campoEditando == 1) lcd.setCursor(4, 1);
        else if (campoEditando == 2) lcd.setCursor(9, 1);
        else if (campoEditando == 2) lcd.setCursor(9, 1);
        else if (campoEditando == 3) lcd.setCursor(12, 1);
        else if (campoEditando == 4) lcd.setCursor(15, 1);
    }

    delay(50); // Delay operacional para manter a taxa de atualização do teclado suave
}

